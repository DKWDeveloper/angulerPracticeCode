import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-childcomponent',
  templateUrl: './childcomponent.component.html',
  styleUrls: ['./childcomponent.component.css']
})
export class ChildcomponentComponent {
  @Input() sendData: any
  @Input() obj: any
  @Input()
  sayHello!: () => void

  @Output() sendValue = new EventEmitter();


  onkeyUp(item: any) {
    return this.sendValue.emit(item);
  }


  // get() {
  //   this.func()
  // }


}
