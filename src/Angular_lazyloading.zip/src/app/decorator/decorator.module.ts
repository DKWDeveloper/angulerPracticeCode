import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DecoratorRoutingModule } from './decorator-routing.module';
import { DecoratorComponent } from './decorator.component';
import { ParentcomponentComponent } from './parentcomponent/parentcomponent.component';
import { ChildcomponentComponent } from './childcomponent/childcomponent.component';


@NgModule({
  declarations: [
    DecoratorComponent,
    ParentcomponentComponent,
    ChildcomponentComponent
  ],
  imports: [
    CommonModule,
    DecoratorRoutingModule
  ]
})
export class DecoratorModule {
  constructor() {
    console.log('decorator-module')
  }
}
