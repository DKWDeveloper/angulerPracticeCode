import { Component } from '@angular/core';

@Component({
  selector: 'app-decorator',
  templateUrl: './decorator.component.html',
  styleUrls: ['./decorator.component.css']
})
export class DecoratorComponent {

  sendData: any = 100;

  data = {
    name: 'reyan',
    last: 'roger'
  }

  outPutData: any;

  getData(data: any) {
    this.outPutData = data;
  }

  Hello() {
    return console.log('hello my name is reyan')
  }


}
