import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChildcomponentComponent } from './childcomponent/childcomponent.component';
import { DecoratorComponent } from './decorator.component';
import { ParentcomponentComponent } from './parentcomponent/parentcomponent.component';

const routes: Routes = [
  { path: '', component: DecoratorComponent },
  { path: 'child', component: ChildcomponentComponent },
  { path: 'parent', component: ParentcomponentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DecoratorRoutingModule { }
