import { Component } from '@angular/core';

@Component({
  selector: 'app-driven-form',
  templateUrl: './driven-form.component.html',
  styleUrls: ['./driven-form.component.css']
})
export class DrivenFormComponent {
  field: any = { title: '' };

  /**This method is used in parent component like app.component.ts */
  clicked(){
    console.log('i am coming from driven-form-component')
  }

  formSubmit(value: any) {
    console.log(value)
  }

}
