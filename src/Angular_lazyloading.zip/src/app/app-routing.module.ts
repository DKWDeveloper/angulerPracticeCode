import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  // { path: '', loadChildren: () => import('./company/company.module').then(m => m.CompanyModule) },
  // { path: 'admin', loadChildren: () => import('./admin/admin.module').then(mod => mod.AdminModule) },
  
  { path: 'google', loadChildren: () => import('./google/google.module').then(m => m.GoogleModule) },
  { path: 'Amazon', loadChildren: () => import('./amazon/amazon.module').then(m => m.AmazonModule) },
  {path: 'decorator', loadChildren: () => import('./decorator/decorator.module').then(module => module.DecoratorModule)}

  // {path: 'company', loadChildren: 'app/company.module#CompanyModule'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
