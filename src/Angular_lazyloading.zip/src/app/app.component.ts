import { Component, ViewChild } from '@angular/core';
import { DrivenFormComponent } from './driven-form/driven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular_lazyloading';
  title1 = 'Basic pipe of angular';
  tool: string = 'angular';

  isRed: boolean = false;
  styleOne: any = true;
  styleTwo: any = true;
  today = Date();

  @ViewChild(DrivenFormComponent) formComponent!: DrivenFormComponent
  @ViewChild(ReactiveFormComponent) component!: ReactiveFormComponent



  onSubmit() {
    this.formComponent.clicked();
  }

  showData(){
  return this.component.name
  }


  user = {
    name: 'Deepak',
    last: 'kumar'
  }

  capitalize(item: any) {
    // console.log(item)
    return item.toUpperCase()
  }



  toggleColor() {
    this.isRed = !this.isRed
  }
}
