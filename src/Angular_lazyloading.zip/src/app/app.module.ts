import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DrivenFormComponent } from './driven-form/driven-form.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component'
import { ReactiveFormsModule } from '@angular/forms';
import { PdfcreatorComponent } from './pdfcreator/pdfcreator.component';


// import { CompanyModule } from './company/company.module';
// import { CompanycreateComponent } from './companycreate/companycreate.component';

@NgModule({
  declarations: [
    AppComponent,
    DrivenFormComponent,
    ReactiveFormComponent,
    PdfcreatorComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
    // CompanyModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    console.log('app-module')
  }
}
