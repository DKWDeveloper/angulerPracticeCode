import { Component, ElementRef, ViewChild } from '@angular/core';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-pdfcreator',
  templateUrl: './pdfcreator.component.html',
  styleUrls: ['./pdfcreator.component.css']
})
export class PdfcreatorComponent {
  @ViewChild('table') table!: ElementRef;

  // value: boolean = true;

  createPdf() {
    const pdf = new jsPDF('p', 'pt', 'a4');

    const options = {
      background: 'white',
      scale: 3
    }
    pdf.html(this.table.nativeElement, {
      callback: (pdf) => {
        pdf.save('table.pdf');
      }
    })
  }

  // createPdf() {
  //   const doc = new jsPDF();
  //   doc.text('Deepak Kumar', 10, 10);
  //   doc.save('table.pdf')
  // }


  // createPdf() {
  //   const doc = new jsPDF();
  //   const element = this.table.nativeElement;
  //   const html = element.innerHTML;
  //   doc.fromHTML(html,15,15);
  //   doc.save('table.pdf')
  // }


}
