import { Component } from '@angular/core';

@Component({
  selector: 'app-companycreate',
  templateUrl: './companycreate.component.html',
  styleUrls: ['./companycreate.component.css']
})
export class CompanycreateComponent {

}
