import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanycreateComponent } from './companycreate.component';

describe('CompanycreateComponent', () => {
  let component: CompanycreateComponent;
  let fixture: ComponentFixture<CompanycreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanycreateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanycreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
