import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompanyRoutingModule } from './company-routing.module';
import { CompanycreateComponent } from './companycreate/companycreate.component';
import { CompanylistComponent } from './companylist/companylist.component';


@NgModule({
  declarations: [
    CompanycreateComponent,
    CompanylistComponent
  ],
  imports: [
    CommonModule,
    CompanyRoutingModule
  ]
})
export class CompanyModule {
  constructor() {
    console.log('company Module')
  }
}
