import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DBOperation } from './services/db-operation';
import { filter, map, Observable } from 'rxjs';


import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { User } from './services/user.interface';
import { UserService } from './services/user.service';
import { MustMatch } from './helpers/must-match-validators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'crud_App';
  submitted: boolean = false;
  buttonText: string = "Submit";
  dbops: DBOperation;





  // registerForm: FormGroup = new FormGroup({})
  registerForm: FormGroup;
  users: User[] = [];




  constructor(private _toast: ToastrService, private _fb: FormBuilder, private _userService: UserService) { }

  ngOnInit() {
    this.setFromState();
    this.getAllUsers();

  }


  setFromState() {
    this.buttonText = 'Submit'
    this.dbops = DBOperation.create;

    // Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9|[12][0-9]|3[01])$/)

    this.registerForm = this._fb.group({
      id: [0],
      title: ['', Validators.required],
      firstName: ['', Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(10)])],
      lastName: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(10)])],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      dob: ['', Validators.compose([Validators.required,])],
      password: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(6)])],
      confirmPassword: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    }, {
      Validators: MustMatch('password', 'confirmPassword')
    })
  }

  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // console.log(this.users)

    console.log(this.registerForm.value)

    if (this.registerForm.invalid) {
      return;
    }
    // else {

    switch (this.dbops) {
      case DBOperation.create:
        this._userService.addUser(this.registerForm.value).subscribe(res => {
          console.log(res)
          this._toast.success("User Added !!", "User Registration");
          this.getAllUsers();
          this.onCancel();
        });
        break;
      case DBOperation.update:
        this._userService.updateUser(this.registerForm.value).subscribe(res => {
          this._toast.success("User Updated !!", "User Data");
          this.getAllUsers();
          this.onCancel();
        });
        break;
    }


    // }

  }

  onCancel() {
    this.registerForm.reset();
    this.buttonText = "Submit";
    this.dbops = DBOperation.create
    this.submitted = false
  }


  getAllUsers() {
    this._userService.getUsers().subscribe((res: User[]) => {
      this.users = res
    })
  }


  Edit(user: number) {

    this.buttonText = "Update";
    this.dbops = DBOperation.update
    // alert(user)
    let user_find = this.users.find((u: User) => u.id === user);
    this.registerForm.patchValue(user_find);


    this.registerForm.get('password').setValue('');
    this.registerForm.get('confirmPassword').setValue('');
    this.registerForm.get('acceptTerms').setValue(false);
  }


  Delete(user: number) {
    // alert(user)
    // this._userService.deleteUser(user).subscribe(res => {
    //   console.log(res)
    //   this.getAllUsers();
    //   this._toast.success("Deleted Success !!", "User Data");
    // })

    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover deleted record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {

        this._userService.deleteUser(user).subscribe(res => {
          console.log(res)
          this.getAllUsers();
          this._toast.success("Deleted Success !!", "User Data");

          // Swal.fire(
          //   'Deleted',
          //   'Your record has been deleted.',
          //   'success'
          // )
        })
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your record is safe :)',
          'error'
        )
      }
    })

  }
}
