import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';

const routes: Routes = [
  // {
  //   path: 'parent', 
  //   component: ParentComponent,
  //   children: [
  //     { path: 'child1', component: Child1Component },
  //     { path: 'child2', component: Child2Component },
  //     { path: '', redirectTo: 'child1', pathMatch: 'full' },
  //   ]
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
