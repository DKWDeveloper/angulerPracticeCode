/**Basic concept of promise */

// let promise = new Promise((resolve, reject) => {
//     islogin = true;
//     if (islogin) {
//         resolve('user is login')
//     } else {
//         reject('user not login')
//     }
// })

// promise.then((res) => {
//     console.log('resolve is called', res)
// }).catch((error) => {
//     console.log('reject is called', error)
// }).finally((res) => {
//     console.log('final result')
// })


/**Now using promise */
function getCheeze() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const cheeze = '🧀'
            resolve(cheeze);
        }, 8000)
    })
}

function makeDought(cheeze) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const dought = cheeze + '🍩'
            resolve(dought)
        }, 6000)
    })
}

function makeBurger(dought) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const burger = dought + '🍔';
            resolve(burger)
            // reject('rejected')
        }, 1000)
    })
}

// getCheeze().then((cheeze) => {
//     console.log('here is cheeze', cheeze)
//     return makeDought(cheeze)
// }).then((dought) => {
//     console.log('here is dought', dought)
//     return makeBurger(dought)
// }).then((burger) => {
//     console.log('here is burger', burger)
// }).catch((error) => {
//     console.log('error occured', error)
// }).finally(() => {
//     console.log('test ended')
// })

// forkJoin(getCheeze(), makeDought(cheeze), makeDought(cheeze)(data) => {
//     let firstP = data[0];
//     let sec
// })

// simplify the code using async and awiat method

async function usingAsync() {
    try {
        const cheeze = await getCheeze();
        console.log('here is cheeze', cheeze)

        const dought = await makeDought(cheeze);
        console.log('here is dought', dought)

        const burger = await makeBurger(dought);
        console.log('here is burger', burger)
    } catch (error) {
        console.log('error occured')
    } finally {
        console.log('final result')
    }
}
usingAsync()

//
