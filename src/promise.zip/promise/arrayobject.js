/**question.1-> This is array object using splice method delete particular id object */
/**Questions.2-> second is sort the array element */

let arrObj = [
    { id: 1, name: 'Deepak', lastName: 'kumar', mob: 123456 },
    { id: 2, name: 'john', lastName: 'kumar', mob: 123456 },
    { id: 3, name: 'Rock', lastName: 'kumar', mob: 123456 },
    { id: 4, name: 'Rock', lastName: 'kumar', mob: 123456 }

]
function del(id) {
    let index = arrObj.findIndex((item) => item.id === id)
    let spl = arrObj.splice(index, 1)
    console.log('deleted item', spl)
    console.log('original array', arrObj)
}
// let num = parseInt(prompt('Enter your id'))
// del(num)


/**Using for loop */
function del2(id) {
    for (let i = 0; i < arrObj.length; i++) {
        if (arrObj[i].id === id) {
            let sp = arrObj.splice(i, 1)
            console.log('deleted', sp)
        }
    }
    console.log('original array', arrObj)
}
del2(4)

/**This is array short in */
let numbers = [2, 7, 8, 1]

//ascending order
for (let i = 0; i < numbers.length; i++) {
    // console.log(i)
    for (let j = 0; j < numbers.length; j++) {
        console.log(numbers)
        if (numbers[j] > numbers[j + 1]) {
            let temp = numbers[j];
            numbers[j] = numbers[j + 1];
            numbers[j + 1] = temp;
        }
        // else{
        //     console.log('hello')
        // }
    }
}
console.log('required ascending order output', numbers)

//decending order
// for (let i = 0; i < numbers.length; i++) {
//     for (let j = 0; j < numbers.length; j++) {
//         if (numbers[j] < numbers[j + 1]) {
//             let temp = numbers[j];
//             numbers[j] = numbers[j + 1];
//             numbers[j + 1] = temp;
//         }
//     }
// }
// console.log(numbers)










