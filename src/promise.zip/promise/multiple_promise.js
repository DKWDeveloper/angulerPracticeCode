
function promise_first() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('promise_one');
            resolve(10);
        }, 9000);
    })
};

function promise_second() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('promise_second');
            resolve(20);
        }, 1000);
    });
};

function promise_Thrid() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('promise_thrid');
            resolve(30);
        }, 1000);
    });
};

const promiseArr = [promise_first(), promise_second(), promise_Thrid()]

// Promise.all(promiseArr)
//     .then((res) => {
//         console.log(res)
//     })
//     .catch((error) => {
//         console.log(error)
//     })

Promise.race(promiseArr)
    .then((res) => {
        console.log(res)
    })
    .catch((error) => {
        console.log(error)
    })
/**This reduce the length of code */
// let promiseCall = function (value, msg) {
//     return function (resolve, reject) {
//         setTimeout(() => {
//             console.log(`The ${msg} promise has resolved`)
//             resolve(value)
//         }, value * 100)
//     }
// }
// let promise_1 = new Promise(promiseCall(10, 'first'))
// let promise_2 = new Promise(promiseCall(20, 'second'))
// let promise_3 = new Promise(promiseCall(30, 'thrid'))

// Promise.all([promise_1, promise_2, promise_3]).then((res) => {
//     // console.log(res[1])
//     let total = 0;
//     for (let i = 0; i < res.length; i++) {
//         total += res[i]
//     }
//     console.log(`Total value of promise ${total}`)

// })

