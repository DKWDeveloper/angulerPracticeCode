/** Fetch data using fetch api in javascript */
// let base_url = 'https://jsonplaceholder.typicode.com/users';
// function fetchData() {
//     return new Promise((resolve, reject) => {
//         const data = fetch(base_url)
//         console.log(data)
//         if (data.status == 200) {
//             resolve(data.response)
//         } else {
//             reject('data is not found')
//         }

//     }).then((res) => console.log('data>>>', res)).catch(error => console.log(error))
// }
// fetchData()


//Make a GET request to a URL
fetch('https://jsonplaceholder.typicode.com/todos/500')
    // Use the Promise returned by fetch
    .then(response => {
        // Check if the response was successful
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        // If successful, parse the response as JSON and return it
        return response.json();
    })
    // Use the Promise returned by response.json()
    .then(data => {
        // Log the JSON data to the console
        console.log(data);
    })
    // Handle any errors that occurred during the previous steps
    .catch(error => {
        console.error('Error:', error);
    });
