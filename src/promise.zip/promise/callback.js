/**Java script has synchonous nature by default  */
// console.log('Hello');
// console.log('Deepak');
// console.log('Kumar')

/**Now Asynchronius  */
// console.log('Hello');
// setTimeout(function () {
// console.log('setTimeOu')
// },3000)
// console.log('Deepak');
// console.log('Kumar')



/**This code about callback and callback hell */

/**
// example 1
function myDisplayer(num) {
    document.getElementById("demo").innerHTML = num;
}

function myCalculator(num1, num2, myCallback) {
    let sum = num1 + num2;
    myCallback(sum);
}

myCalculator(5, 5, myDisplayer);

//example 2
function sayHello(add) {
    console.log('hello ' + add)
}

function hi(n1, n2, callback) {
    const sum = n1 + n2;
    callback(sum)

}
hi(5, 3, sayHello) */

function getCheese(callback1) {
    setTimeout(() => {
        const cheese = '🧀';
        console.log('here cheese', cheese);
        callback1(cheese);
    }, 8000)
}

function makeDough(cheese, callback2) {
    setTimeout(() => {
        const dough = cheese + '🍩';
        console.log('here is dough', dough)
        callback2(dough)
    }, 6000)
}

function bakePizza(dough, callback3) {
    setTimeout(() => {
        const pizza = dough + '🍕';
        console.log('here is pizza', pizza);
        callback3(pizza)
    }, 1000)
}

getCheese((cheese) => { // 1st time 
    makeDough(cheese, (dough) => {
        bakePizza(dough, (pizza) => {
            // console.log('got pizza', pizza)
        })
    })
})

// >>pizza -> dough -> cheese

//example 2 callback hell
// fetch('https://example.com/data1', function (data1) {
//     fetch('https://example.com/data2/' + data1.id, function (data2) {
//         fetch('https://example.com/data3/' + data2.id, function (data3) {
//             // do something with data3
//         });
//     });
// });



//My example
// function getData(callback1) {
//     setTimeout(() => {
//         const str = '🍞'
//         console.log('here is food', str)
//         callback1(str)
//     }, 2000)
// }

// function getData2(str, callback2) {
//     setTimeout(() => {
//         const str2 = str + '🍗'
//         console.log('here is food', str2)
//         callback2(str2)
//     }, 2000)
// }

// function getData3(str3, callback3) {
//     setTimeout(() => {
//         const fooed = str3 + '🥙'
//         console.log('here is food', fooed)
//         // callback3(str3)
//     }, 2000)
// }

// getData((str) => {
//     // console.log(str)
//     getData2(str, (str2) => {
//         getData3(str2, () => {

//         })
//     })
// })
