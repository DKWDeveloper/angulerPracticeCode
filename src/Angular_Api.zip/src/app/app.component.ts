import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { BookService } from './service/book.service';
// import { Book } from './book';
import { Post } from './book';
import { map, filter } from 'rxjs/operators';
import { Observable } from 'rxjs';
// import { format } from 'path';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'get Api';
  datasaved = false;
  // bookForm: FormGroup;
  softBooks: any = [];
  posts: any[] = [];






  constructor(private formbuilder: FormBuilder, private bookservice: BookService) { }

  fetchData() {


    // constructor(private postService: PostService) { }


    // this.bookservice.getPosts().pipe(
    //   map(posts => posts.filter(post => post.userId === 1))
    // ).subscribe(posts => {
    //   this.posts = posts;
    // });
    
    this.bookservice.getData().pipe(
      map(posts => posts.filter((post: { userId: number; }) => post.userId === 1))
    ).subscribe(posts => {
      this.softBooks = posts;
    });
  }

  ngOnInit(): void {
    this.fetchData()
  }

  // this.bookservice.getData().pipe(map(d => d.filter(v => v.id === 1))).subscribe((result) => {
  //   this.softBooks = result
  // })





  // ngOnInit() {
  //   this.bookForm = this.formbuilder.group({
  //     name: ['', [Validators.required]],
  //     category: ['', [Validators.required]],
  //     writer: ['', [Validators.required]]
  //   });
  //   this.getsoftBooks()
  // }


  // formSubmit() {
  //   this.datasaved = false;
  //   let book = this.bookForm.value;
  //   this.createbooks(book)
  //   this.bookForm.reset();
  // }

  // createbooks(book: Book) {
  //   this.bookservice.createbook(book).subscribe(book => {
  //     this.datasaved = true;
  //     this.getsoftBooks();
  //   })
  // }
  // getsoftBooks() {
  //   this.bookservice.getBooksFromStore().subscribe((bookdata) => {
  //     console.log(bookdata)
  //     this.softBooks = bookdata;
  //   })
  // }

}


