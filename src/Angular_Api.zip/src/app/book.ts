// export interface Book {
//     id: number;
//     name: string;
//     category: string,
//     writer: string
// }


// export interface Book {
//     : number;
//     name: string;
//     ca: string,
//     writer: string
// }


export interface Post {
    title: string;
    body: string;
    userId: number;
    id: number
  }
  