import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { filter, Observable } from 'rxjs';
import { Post } from '../book';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  bookUrl = '/api/books';
  // url = 'https://jsonplaceholder.typicode.com/users';
  url = 'https://jsonplaceholder.typicode.com/posts/1'
  // bookUrl = 'http://localhost:3000/student'
  // constructor(private http: HttpClient) { }


  private baseUrl = 'https://jsonplaceholder.typicode.com';

  constructor(private http: HttpClient) { }

  getPosts(): Observable<Post> {
    return this.http.get<Post>(`${this.baseUrl}/posts`);
  }

  // createbook(book: Book): Observable<Book> {
  //   let httpheaders = new HttpHeaders()
  //     .set('Content-Type', 'application/json');
  //   let options = {
  //     headers: httpheaders
  //   };

  //   return this.http.post<Book>(this.bookUrl, book, options)
  // }


  getData(): Observable<any> {
    return this.http.get<any>(this.url)

    // return dataconsole.log("map data",data.id)

  }

  // getBooksFromStore(): Observable<Book[]> {

  //   return this.http.get<Book[]>(this.bookUrl);
  // }

}
