import { Component, ViewChild } from '@angular/core';
import { ViewchildComponent } from './viewchild/viewchild.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'week_10';



  @ViewChild(ViewchildComponent) value: ViewchildComponent;


ngOnInit() {
  
}


  getValue12() {
    console.log('This value', this.value)
    console.log(this.value.sayHello())
  }

}
