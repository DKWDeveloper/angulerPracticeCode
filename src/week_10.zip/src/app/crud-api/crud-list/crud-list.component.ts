import { Component } from '@angular/core';
import { CrudServiceApiService } from '../Service/crud-service-api.service';
import { Data } from '../Service/interface';

@Component({
  selector: 'app-crud-list',
  templateUrl: './crud-list.component.html',
  styleUrls: ['./crud-list.component.css']
})
export class CrudListComponent {

  dataList: Data[] = [];
  userData: any;

  constructor(private _data: CrudServiceApiService) { }

  // ngOnChanges() {
  //   console.log(this.userData);
  // }

  ngOnInit(): void {
    this.fetchData()
  }

  fetchData() {
    this._data.getData().subscribe((res: Data[]) => {
      return this.dataList = res;
    })
  }

  edit(id: any) {
    let findItem = this.dataList.find((ele) => ele.id === id)
    this._data.subject.next(findItem)
  }

  deleteItem(id: number) {
    console.log(id)
    this._data.deleteData(id).subscribe((res: any) => {
      this.fetchData()
    })
  }


  sayHello() {
    console.log('Hello world')
  }

}
