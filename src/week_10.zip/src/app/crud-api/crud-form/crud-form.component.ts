import { Component, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CrudServiceApiService } from '../Service/crud-service-api.service';


@Component({
  selector: 'app-crud-form',
  templateUrl: './crud-form.component.html',
  styleUrls: ['./crud-form.component.css']
})
export class CrudFormComponent {
  subject: any;
  myForm: FormGroup;


  constructor(private _data: CrudServiceApiService) { this.formState() }

  ngOnInit() {
    this.getObj()

  }

  formState() {
    this.myForm = new FormGroup({
      id: new FormControl(0),
      firstName: new FormControl('', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(10)])),
      password: new FormControl('', Validators.compose([Validators.required, Validators.email, Validators.minLength(4)])),
      confirmPassword: new FormControl('', Validators.compose([Validators.required, Validators.email, Validators.minLength(4)]))
    })
  }


  onSubmit() {

  }


  // ngOnChanges() {


  // }
  updateObj() {
this._data.putData()
  }



  getObj() {
    this._data.subject.subscribe((res) => {
      console.log(res)
      this.subject = res
    })
  }

}