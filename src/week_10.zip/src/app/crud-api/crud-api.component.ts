import { Component } from '@angular/core';

@Component({
  selector: 'app-crud-api',
  templateUrl: './crud-api.component.html',
  styleUrls: ['./crud-api.component.css']
})
export class CrudApiComponent {

}
