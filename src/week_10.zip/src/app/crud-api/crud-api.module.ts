import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CrudApiRoutingModule } from './crud-api-routing.module';
import { CrudApiComponent } from './crud-api.component';
import { CrudFormComponent } from './crud-form/crud-form.component';
import { CrudListComponent } from './crud-list/crud-list.component';

import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { CrudServiceDbService } from './Service/crud-service-db.service';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    CrudApiComponent,
    CrudFormComponent,
    CrudListComponent
  ],
  imports: [
    CommonModule,
    CrudApiRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    HttpClientInMemoryWebApiModule.forRoot(CrudServiceDbService)
  ]
})
export class CrudApiModule { }
