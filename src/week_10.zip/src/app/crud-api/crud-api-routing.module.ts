import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CrudApiComponent } from './crud-api.component';
import { CrudFormComponent } from './crud-form/crud-form.component';
import { CrudListComponent } from './crud-list/crud-list.component';

const routes: Routes = [
  { path: '', component: CrudApiComponent },
  { path: 'form', component: CrudFormComponent },
  { path: 'list', component: CrudListComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CrudApiRoutingModule { }
