import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Data } from './interface';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudServiceApiService {

  Base_url = 'http://localhost:4200/api/user'


  constructor(private _http: HttpClient) { }

  subject = new Subject<any>();

  /**This method get the data form api */
  getData() {
    return this._http.get(this.Base_url);
  }

  /**This method create the data in table or we can say that post the data */
  postData(data: any) {
    return this._http.post(`${this.Base_url}`, data)
  }

  /**This method put or update the data */
  putData(data: Data) {
    return this._http.put(`${this.Base_url}/${data.id}`, data)
  }

  /**This method is used for Delete the data by using id */
  deleteData(id: any) {
    return this._http.delete(`${this.Base_url}/${id}`)
  }



}
