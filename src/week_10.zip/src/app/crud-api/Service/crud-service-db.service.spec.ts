import { TestBed } from '@angular/core/testing';

import { CrudServiceDbService } from './crud-service-db.service';

describe('CrudServiceDbService', () => {
  let service: CrudServiceDbService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CrudServiceDbService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
