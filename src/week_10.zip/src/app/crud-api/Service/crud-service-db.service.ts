import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Data } from './interface';

@Injectable({
  providedIn: 'root'
})
export class CrudServiceDbService implements InMemoryDbService {

  constructor() { }

  createDb() {
    let user: Data[] = [
      { id: 1, firstName: 'Deepak', mobile: 123456789, email: 'dk@gmail.com', confirmEmail: 'dk@gmial.com' }
    ]

    return { user };
  }

}
