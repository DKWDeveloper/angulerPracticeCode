import { TestBed } from '@angular/core/testing';

import { CrudServiceApiService } from './crud-service-api.service';

describe('CrudServiceApiService', () => {
  let service: CrudServiceApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CrudServiceApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
