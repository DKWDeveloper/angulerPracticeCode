export interface Data {
    id: number,
    firstName: string,
    mobile: number,
    email: string,
    confirmEmail: string

}