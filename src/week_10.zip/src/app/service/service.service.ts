import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { User } from '../user/userlist/interface';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  baseUrl = 'http://localhost:4200/api/'

  constructor(private _http: HttpClient) { }

  getMethod() {
    return this._http.get(this.baseUrl + 'users')
  }

  postMethod(data: any) {
    return this._http.post(`${this.baseUrl}users`, data)
  }

  putMethod(user: User) {
    console.log(user)
    return this._http.put(`${this.baseUrl}users/${user.id}`, user)
  }

  deleteMethod(id: number) {
    return this._http.delete(`${this.baseUrl}users/${id}`)
  }
}
