import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedserviceService {

  constructor() { }

  objValue: any
  objData(obj: any) {
    this.objValue = obj
    return this.objValue
  }

}
