import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsercreateComponent } from './usercreate/usercreate.component';
import { UserlistComponent } from './userlist/userlist.component';

const routes: Routes = [
  { path: 'usercreate', component: UsercreateComponent },
  { path: 'userlist', component: UserlistComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
