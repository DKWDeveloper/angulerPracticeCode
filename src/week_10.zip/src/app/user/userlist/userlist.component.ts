import { Component } from '@angular/core';
import { SharedserviceService } from 'src/app/service/sharedservice.service';
import { ServiceService } from '../../service/service.service';

import { User } from './interface';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent {

  item: User[] = [];

  constructor(private _sr: ServiceService, private _sh: SharedserviceService) { }

  ngOnInit() {
    this.fetchData()
  }


  fetchData() {
    this._sr.getMethod().subscribe((res: any) => {
      this.item = res
      console.log(res)

    })
  }

  onDelete(id: number) {
    this._sr.deleteMethod(id).subscribe((res: any) => {
      this.fetchData()
    })
  }

  edit(id: number) {
    let findData = this.item.find((element) => element.id === id)
    this._sh.objData(findData)

  }

  onUpdate() { }

}
