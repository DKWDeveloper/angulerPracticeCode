export interface User{
    id: number,
    title: string,
    completed: boolean,
}