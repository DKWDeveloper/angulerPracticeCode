import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { SharedserviceService } from 'src/app/service/sharedservice.service';
import { ServiceService } from '../../service/service.service';

@Component({
  selector: 'app-usercreate',
  templateUrl: './usercreate.component.html',
  styleUrls: ['./usercreate.component.css']
})
export class UsercreateComponent {

  myForm: FormGroup = new FormGroup({
    id: new FormControl(),
    title: new FormControl('',[Validators.required]),
    last: new FormControl(''),
    email: new FormControl('')
  })

  constructor(private _sr: ServiceService, private _shared: SharedserviceService) { }

  ngOnInit() {
    // this.onSubmit()
    this.editFunction()
    console.log('my form value', this.myForm.value)
  }
  isdisabled: boolean = true;
  title: string= '';

  onSubmit() {
    this.isdisabled = false;
    this._sr.postMethod(this.myForm.value).subscribe((res: any) => {
      console.log(res)
      this._sr.getMethod();

      console.log('submitted')
    })

    // this._sr.putMethod(this._shared.objValue).subscribe((res: any) => {
    //   this._sr.getMethod();
    // })



  }


  editFunction() {
    this.myForm.patchValue(this._shared.objValue)
    console.log('edit function')

  }


  onUpdate() {
    this._sr.putMethod(this.myForm.value).subscribe((res) => {
      this._sr.getMethod();

    })
  }

}
