import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  {path: '', loadChildren: ()=> import('./user/user.module').then(module => module.UserModule)},
  { path: 'crudApi', loadChildren: () => import('./crud-api/crud-api.module').then(m => m.CrudApiModule) }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
  ]
})
export class AppRoutingModule { }
