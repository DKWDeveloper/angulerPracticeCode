import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { UserModule } from './user/user.module';
import { AppRoutingModule } from './app-routing.module';
import { UserRoutingModule } from './user/user-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { ServiceService } from './service/service.service';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { HttpClientModule } from '@angular/common/http';
import { ServicedbService } from './serviceDB/servicedb.service';
import { CrudApiModule } from './crud-api/crud-api.module';
import { ViewchildComponent } from './viewchild/viewchild.component';





@NgModule({
  declarations: [
    AppComponent,
    ViewchildComponent,
  
  ],
  imports: [
    BrowserModule,
    UserModule,
    AppRoutingModule,
    UserRoutingModule,
    ReactiveFormsModule,
    HttpClientInMemoryWebApiModule,
    HttpClientModule,
    CrudApiModule
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

}
