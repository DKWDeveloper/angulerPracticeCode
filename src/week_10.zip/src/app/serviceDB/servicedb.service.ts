import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { User } from '../user/userlist/interface';


@Injectable({
  providedIn: 'root'
})
export class ServicedbService implements InMemoryDbService {

  constructor() { }

  createDb() {
    let users: User[] = [
      { id: 1, title: 'aman', completed: true }
    ]
    return { users };
  }
}
