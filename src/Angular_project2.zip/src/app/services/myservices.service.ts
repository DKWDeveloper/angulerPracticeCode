import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyservicesService {
  // get Api-------
  // url = 'https://jsonplaceholder.typicode.com/comments?postId=1'
  // url = 'https://reqres.in/api/users?page=2'
  url = 'http://localhost:3000/student'
  // url = 'https://jsonplaceholder.typicode.com/comments?id=5'

  putData: Object = { body: 'angular put method' };

  constructor(private http: HttpClient) { }
  users() {
    return this.http.get(this.url)
  }



  //post Api------
  postDataInApi(userData: any) {
    console.log("service ka user data", userData)
    return this.http.post(this.url, userData)
  }


  // get Table Data id
  getTableDataId(dataid: string) {
    console.log("dataId", dataid)
    console.log(this.http.get(this.url + "/" + dataid))
    return this.http.get(this.url + "/" + dataid);
  }

  //put method in Angular
  header: Object = new HttpHeaders({ 'Content-Type': 'application/json' });
  putDataInApi(data: string) {
    // console.log(id)
    return this.http.put(this.url, data)
    // console.log("putmethod", userPut)
  }

  myservices() {
    return [
      { name: 'Sumit', last: 'kumar' },
      { name: 'sam', last: 'reyan' },

    ]

    // return "nmae"
  }
  name = 'Aman'
  myservices2() {
    return this.name

  }
}
