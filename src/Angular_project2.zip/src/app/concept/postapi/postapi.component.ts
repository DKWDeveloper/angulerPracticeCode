import { Component } from '@angular/core';
import { MyservicesService } from 'src/app/services/myservices.service';


@Component({
  selector: 'app-postapi',
  templateUrl: './postapi.component.html',
  styleUrls: ['./postapi.component.css']
})
export class PostapiComponent {

  // postData() {

  // }

  constructor(private service: MyservicesService) { }



  username: string = '';
  postData(data: any) {
    // this.username = item.email;
    // console.log(this.username)
    // this.service.putDataInApi(data)
    console.warn('formData', data)
    this.service.postDataInApi(data).subscribe((response) => {
      console.log('post data', response)
    })

  }
}
