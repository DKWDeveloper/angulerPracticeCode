import { Component, OnInit } from '@angular/core';
import { MyservicesService } from 'src/app/services/myservices.service';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['./api.component.css']
})
export class ApiComponent implements OnInit {


  username: string = '';
  postData(data: any) {
    // this.username = item.email;
    // console.log(this.username)
    // this.service.putDataInApi(data)
    console.warn('formData', data)
    this.apiData.postDataInApi(data).subscribe((response) => {
      console.log('post data', response)
    })

  }

  usersData: any;

  constructor(private apiData: MyservicesService) { }

  ngOnInit(): void {
    this.apiData.users().subscribe((response) => {
      console.log('Data', response)
      this.usersData = response;
    })
  }

  putData(data: string) {
    this.apiData.putDataInApi(data).subscribe((response) => {
      console.log("put", response)
    })
  }
}
