import { Component } from '@angular/core';
import { MyservicesService } from './services/myservices.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular_project2';
  title2 = 'Send Data parent to child component'
  title3 = 'Send Data Child to Parent'
  value = 10
  name = 'Deepak'
  off = true
  userLogin(item: any) {
    // console.warn(item)
  }

  user: any;
  constructor(private data: MyservicesService) {
    // console.log("myservices", data.myservices())
    this.user = data.myservices()
  }

  childcom() {
    this.value = Math.floor(Math.random() * 11)
  }

  data2 = 'child data'
  sendData(value: string) {
    // console.log("parent component", value)

    this.data2 = value
  }
}
