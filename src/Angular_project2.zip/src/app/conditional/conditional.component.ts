import { Component } from '@angular/core';

@Component({
  selector: 'app-conditional',
  templateUrl: './conditional.component.html',
  styleUrls: ['./conditional.component.css']
})
export class ConditionalComponent {
  title = 'Topic Conditional if-else';
  title2 = 'Multiple Conditional else-if';
  title3 = 'Switch Case'
  display = "show";
  color = 'brown'
}
