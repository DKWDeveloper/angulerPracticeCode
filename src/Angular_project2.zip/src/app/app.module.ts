import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { UserModuleModule } from './user-module/user-module.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { FormsModule } from '@angular/forms';
import { EventComponent } from './event/event.component'
import { ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { CounterComponent } from './counter/counter.component';
import { ConditionalComponent } from './conditional/conditional.component';
import { LoopComponent } from './loop/loop.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TodoListComponent } from './todo-list/todo-list.component';
import { ChildtoparentComponent } from './childtoparent/childtoparent.component';
import { TwowayBindingComponent } from './twoway-binding/twoway-binding.component'
import { ConceptModule } from './concept/concept.module';
import { HttpClientModule } from '@angular/common/http'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    EventComponent,
    ReactiveFormComponent,
    CounterComponent,
    ConditionalComponent,
    LoopComponent,
    TodoListComponent,
    ChildtoparentComponent,
    TwowayBindingComponent
  ],
  imports: [
    BrowserModule,
    UserModuleModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ConceptModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
