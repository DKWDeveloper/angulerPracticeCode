import { Component } from '@angular/core';
import { MyservicesService } from '../services/myservices.service';

@Component({
  selector: 'app-loop',
  templateUrl: './loop.component.html',
  styleUrls: ['./loop.component.css']
})
export class LoopComponent {
  title = 'For Loop'
  title2 = 'Nested For Loop'
  title3 = 'Style-Binding'
  // user = ['Deepak', 'John', 'Kumar', 'Sunil', 'Rock']
  value = 10
  color = 'red'
  bgColor = 'yellow'


  user:any;
  constructor(private data:MyservicesService){
    console.log("myservices", data.myservices())

    this.user = data.myservices()
  }

  changeColor(){
    this.color = 'yellow'
    this.bgColor = 'red'
  }


  

  userObj = [
    { name: 'Deepak', lastName: 'Kumar', phone: '8544941820', socialAccount: ['facebook', 'whatsapp', 'instagram'] },
    {
      name: 'Sameer',
      lastName: 'Singhla',
      phone: '123456',
      socialAccount: ['linkedIn', 'instagram', 'whatsapp']
    },
    {
      name: 'john',
      lastName: 'Doe',
      phone: '654321',
      socialAccount: ['yahoo', 'google', 'gmail']

    },
    {
      name: 'Amar',
      lastName: 'Kumar',
      phone: '8544941820',
      socialAccount: ['twitter', 'youTube', 'snapchat']

    }
  ]
}
