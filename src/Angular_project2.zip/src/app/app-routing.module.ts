import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { UserListComponent } from './user-module/user-list/user-list.component';
import { UserLoginComponent } from './user-module/user-login/user-login.component';
import { ChildtoparentComponent } from './childtoparent/childtoparent.component';
import { TwowayBindingComponent } from './twoway-binding/twoway-binding.component';
import { ApiComponent } from './concept/api/api.component';
import { PostapiComponent } from './concept/postapi/postapi.component';

const routes: Routes = [
  {
    path: 'h',
    component: HomeComponent
  },
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: 'contact',
    component: ContactComponent
  },
  {
    path: 'userlist',
    component: UserListComponent
  },
  {
    path: 'userlogin',
    component: UserLoginComponent
  },

  {
    path: 'c',
    component: ChildtoparentComponent
  },

  {
    path: 'twb',
    component: TwowayBindingComponent
  },
  {
    path: 'api',
    component: ApiComponent
  },
  {
    path: 'post',
    component: PostapiComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
