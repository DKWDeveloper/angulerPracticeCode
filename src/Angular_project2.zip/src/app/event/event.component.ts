import { Component } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent {
  title = 'Event in angular'
  username: string = '';
  clickEvent(val: any) {
    // console.log("click me");
    console.warn(val);
    // this.username = val.firstName;

  }

  getValue(val: string) {
    // console.log(val: string)
    this.username = val
  }
}


