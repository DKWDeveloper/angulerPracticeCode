import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserListComponent } from './user-list/user-list.component';
import {FormsModule} from '@angular/forms'



@NgModule({
  declarations: [
    UserLoginComponent,
    UserListComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    UserLoginComponent,
    UserListComponent

  ]
})
export class UserModuleModule { }
