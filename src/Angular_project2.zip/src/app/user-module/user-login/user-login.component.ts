import { Component } from '@angular/core';
import { MyservicesService } from 'src/app/services/myservices.service';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent {
  username: string = '';
  userLogin(item: any) {
    this.username = item.email;
    console.warn(item)
  }

  user: any;
  user2: any;
  constructor(private data: MyservicesService) {
    console.log("myservices2", data.myservices())
    this.user = data.myservices()
    this.user2 = data.myservices2()
    console.log(this.user2)
  }





 
}
