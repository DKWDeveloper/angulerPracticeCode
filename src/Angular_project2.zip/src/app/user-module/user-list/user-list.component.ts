import { Component } from '@angular/core';
import { MyservicesService } from 'src/app/services/myservices.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent {
  user: any;
  user2: any;
  constructor(private data: MyservicesService) {
    console.log("myservices2", data.myservices())
    this.user = data.myservices()
    this.user2 = data.myservices2()
    console.log(this.user2)
  }


  usersData: any;
  // constructor(private apiData: MyservicesService) { }
  ngOnInit(): void {
    this.data.users().subscribe((response) => {
      console.log('Data', response)
      this.usersData = response;
    })
  }

}
