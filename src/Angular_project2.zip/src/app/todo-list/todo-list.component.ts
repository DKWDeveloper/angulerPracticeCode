import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent {
  title = 'TodoList!'
  empArray: any[] = [];

  addItem(data: string) {
    // console.log(data)
    this.empArray.push({ id: this.empArray.length, item: data })
    // console.log(this.empArray)
  }

  removeItem(id: number) {
    console.log(id)
   this.empArray = this.empArray.filter((d, i) => d.id !== i)
  }

  @ Input() item = 0
}
